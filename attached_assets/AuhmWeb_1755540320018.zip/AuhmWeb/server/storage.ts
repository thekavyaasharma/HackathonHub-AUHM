import { type Hackathon, type InsertHackathon } from "@shared/schema";
import { randomUUID } from "crypto";

export interface IStorage {
  getAllHackathons(): Promise<Hackathon[]>;
  searchHackathons(query: string): Promise<Hackathon[]>;
  getHackathonsByDomain(domain: string): Promise<Hackathon[]>;
  createHackathon(hackathon: InsertHackathon): Promise<Hackathon>;
}

export class MemStorage implements IStorage {
  private hackathons: Map<string, Hackathon>;

  constructor() {
    this.hackathons = new Map();
    this.seedData();
  }

  private seedData() {
    const sampleHackathons: InsertHackathon[] = [
      {
        name: "BlockChain Builders Hackathon",
        description: "Build the future of decentralized applications with cutting-edge Web3 technologies.",
        domain: "web3",
        date: "Jan 15-17, 2025",
        registrationUrl: "https://example.com/blockchain-builders",
        imageUrl: "https://images.unsplash.com/photo-1639762681485-074b7f938ba0?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=800&h=400"
      },
      {
        name: "AI Innovation Summit",
        description: "Create intelligent solutions using machine learning and artificial intelligence.",
        domain: "ai-ml",
        date: "Feb 8-10, 2025",
        registrationUrl: "https://example.com/ai-innovation",
        imageUrl: "https://images.unsplash.com/photo-1555255707-c07966088b7b?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=800&h=400"
      },
      {
        name: "DataViz Challenge 2025",
        description: "Transform raw data into meaningful insights through advanced analytics and visualization.",
        domain: "data-science",
        date: "Feb 22-24, 2025",
        registrationUrl: "https://example.com/dataviz-challenge",
        imageUrl: "https://images.unsplash.com/photo-1551288049-bebda4e38f71?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=800&h=400"
      },
      {
        name: "CloudNative Hackathon",
        description: "Build scalable, cloud-native applications using modern infrastructure technologies.",
        domain: "cloud",
        date: "Mar 8-10, 2025",
        registrationUrl: "https://example.com/cloudnative",
        imageUrl: "https://images.unsplash.com/photo-1558494949-ef010cbdcc31?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=800&h=400"
      },
      {
        name: "FullStack Developers Summit",
        description: "Create amazing web applications using the latest frontend and backend technologies.",
        domain: "web-dev",
        date: "Mar 22-24, 2025",
        registrationUrl: "https://example.com/fullstack-summit",
        imageUrl: "https://images.unsplash.com/photo-1461749280684-dccba630e2f6?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=800&h=400"
      },
      {
        name: "HealthTech Innovation Lab",
        description: "Develop technology solutions that improve healthcare outcomes and patient experience.",
        domain: "healthcare",
        date: "Apr 5-7, 2025",
        registrationUrl: "https://example.com/healthtech-lab",
        imageUrl: "https://pixabay.com/get/g00111b92d44a2c9fc5a3ca017fd59129908406a222bc8a538a8ac0e143db19c24839834ebc26a4f896a4f7c72df2c0875402621e5bc6f50d12f765f9ccc8ba15_1280.jpg"
      },
      {
        name: "Mobile Apps Championship",
        description: "Build innovative mobile applications for iOS and Android platforms.",
        domain: "mobile",
        date: "Apr 19-21, 2025",
        registrationUrl: "https://example.com/mobile-championship",
        imageUrl: "https://images.unsplash.com/photo-1512941937669-90a1b58e7e9c?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=800&h=400"
      },
      {
        name: "SecureCode Challenge",
        description: "Develop innovative security solutions to protect digital infrastructure and data.",
        domain: "cybersecurity",
        date: "May 3-5, 2025",
        registrationUrl: "https://example.com/securecode-challenge",
        imageUrl: "https://images.unsplash.com/photo-1550751827-4bd374c3f58b?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=800&h=400"
      }
    ];

    sampleHackathons.forEach(hackathon => {
      const id = randomUUID();
      const fullHackathon: Hackathon = {
        ...hackathon,
        id,
        createdAt: new Date()
      };
      this.hackathons.set(id, fullHackathon);
    });
  }

  async getAllHackathons(): Promise<Hackathon[]> {
    return Array.from(this.hackathons.values());
  }

  async searchHackathons(query: string): Promise<Hackathon[]> {
    const allHackathons = await this.getAllHackathons();
    if (!query.trim()) return allHackathons;
    
    const searchTerm = query.toLowerCase();
    return allHackathons.filter(hackathon => 
      hackathon.name.toLowerCase().includes(searchTerm) ||
      hackathon.description.toLowerCase().includes(searchTerm) ||
      hackathon.domain.toLowerCase().includes(searchTerm)
    );
  }

  async getHackathonsByDomain(domain: string): Promise<Hackathon[]> {
    const allHackathons = await this.getAllHackathons();
    if (!domain) return allHackathons;
    
    return allHackathons.filter(hackathon => 
      hackathon.domain.toLowerCase() === domain.toLowerCase()
    );
  }

  async createHackathon(insertHackathon: InsertHackathon): Promise<Hackathon> {
    const id = randomUUID();
    const hackathon: Hackathon = {
      ...insertHackathon,
      id,
      createdAt: new Date()
    };
    this.hackathons.set(id, hackathon);
    return hackathon;
  }
}

export const storage = new MemStorage();
