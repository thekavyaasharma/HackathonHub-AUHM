import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";

export async function registerRoutes(app: Express): Promise<Server> {
  // Get all hackathons
  app.get("/api/hackathons", async (req, res) => {
    try {
      const { search, domain } = req.query;
      
      let hackathons;
      if (search) {
        hackathons = await storage.searchHackathons(search as string);
      } else if (domain) {
        hackathons = await storage.getHackathonsByDomain(domain as string);
      } else {
        hackathons = await storage.getAllHackathons();
      }
      
      res.json(hackathons);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch hackathons" });
    }
  });

  // Chat endpoint for Ollama integration
  app.post("/api/chat", async (req, res) => {
    try {
      const { message } = req.body;
      
      if (!message) {
        return res.status(400).json({ message: "Message is required" });
      }

      // Call local Ollama API
      const ollamaResponse = await fetch("http://localhost:11434/api/generate", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          model: "gemma:2b",
          prompt: `You are AUHM Assistant, a helpful AI that specializes in hackathon guidance. You help students discover hackathons, learn required skills, and navigate their hackathon journey. Answer this question concisely and helpfully: ${message}`,
          stream: false
        })
      });

      if (!ollamaResponse.ok) {
        throw new Error(`Ollama API error: ${ollamaResponse.status}`);
      }

      const data = await ollamaResponse.json();
      res.json({ response: data.response });
      
    } catch (error) {
      console.error("Chat API error:", error);
      
      // Provide helpful fallback responses
      let fallbackResponse = "I'm having trouble connecting to the AI model right now. ";
      
      const message = req.body.message?.toLowerCase() || "";
      
      if (message.includes("roadmap") || message.includes("how to")) {
        fallbackResponse += `Here's a basic roadmap for hackathons:
1. Choose your domain (Web3, AI/ML, etc.)
2. Learn relevant technologies
3. Practice with personal projects
4. Join hackathon communities
5. Form or find a team
6. Start with smaller hackathons

Make sure Ollama is running locally with the gemma:2b model for more detailed guidance!`;
      } else if (message.includes("skills") || message.includes("web3")) {
        fallbackResponse += `For Web3 hackathons, focus on:
- Solidity for smart contracts
- JavaScript/TypeScript for dApps
- React for frontend development
- Web3.js or Ethers.js libraries

Please ensure Ollama is running locally for personalized skill recommendations!`;
      } else {
        fallbackResponse += "Please make sure Ollama is running locally on port 11434 with the gemma:2b model. I can help with hackathon roadmaps, skill requirements, and general guidance once connected!";
      }
      
      res.json({ response: fallbackResponse });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
