# AUHM - An Ultimate Hackathon Matrix

## Overview

AUHM is a comprehensive hackathon discovery platform built for students to explore hackathons around the globe. The application features a modern React frontend with a Node.js/Express backend, providing hackathon listings, search/filtering capabilities, and an AI-powered chatbot assistant. The platform showcases upcoming hackathons across various domains including Web3, AI/ML, Data Science, Cloud Computing, Web Development, Healthcare, and more, with responsive design and dark/light mode support.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Frontend Architecture
The application uses a modern React architecture with TypeScript and a component-based design pattern. The frontend is built using:
- **React 18** with functional components and hooks
- **TypeScript** for type safety and better developer experience
- **Tailwind CSS** with shadcn/ui components for consistent styling
- **Wouter** for lightweight client-side routing
- **TanStack Query** for server state management and API data fetching
- **Custom theme system** with localStorage persistence for dark/light mode switching

The component structure follows a clear separation of concerns with reusable UI components, page components, and custom hooks. The theme system provides seamless dark/light mode transitions with CSS variables for consistent theming.

### Backend Architecture
The backend follows a RESTful API design pattern using:
- **Express.js** as the web framework
- **TypeScript** for type safety across the stack
- **Modular routing** with separated route handlers
- **Memory storage implementation** with an interface-based design for easy database migration
- **Vite integration** for development server and build processes

The server architecture uses dependency injection patterns through the storage interface, making it easy to swap storage implementations from memory to database solutions.

### Data Storage Solutions
Currently implements an in-memory storage system for development and prototyping:
- **MemStorage class** implementing the IStorage interface
- **Seeded sample data** for hackathons across multiple domains
- **Search and filtering capabilities** built into the storage layer
- **Drizzle ORM configuration** prepared for PostgreSQL migration with schema definitions

The storage system is designed with PostgreSQL in mind, using Drizzle ORM for future database integration. The schema defines hackathon entities with proper typing and validation using Zod.

### Authentication and Authorization
Currently, the application doesn't implement user authentication, focusing on public hackathon discovery. The architecture is prepared for future authentication implementation through the existing query client and API patterns.

### API Design
The backend exposes a clean RESTful API:
- **GET /api/hackathons** - Retrieve hackathons with optional search and domain filtering
- **POST /api/chat** - AI chatbot integration endpoint
- Consistent error handling and response formatting
- Request logging and monitoring middleware

## External Dependencies

### AI Integration
- **Local Ollama integration** using the `gemma:2b` model
- **Custom chatbot implementation** named "AUHM Assistant"
- **Fetch-based API calls** to `http://localhost:11434/api/generate`
- **Streaming response handling** for real-time chat interactions

### UI Framework
- **Radix UI primitives** for accessible, unstyled components
- **shadcn/ui component library** for consistent design system
- **Font Awesome icons** for domain-specific visual indicators
- **Tailwind CSS** with custom configuration and CSS variables

### Build and Development Tools
- **Vite** for fast development and optimized production builds
- **ESBuild** for server bundling in production
- **PostCSS** with Autoprefixer for CSS processing
- **Replit integration** with development banner and cartographer support

### Database Integration (Prepared)
- **Neon Database** serverless PostgreSQL connection
- **Drizzle ORM** with kit for schema management and migrations
- **Connection pooling** with connect-pg-simple for session management

The application is designed to run locally on Windows with simple npm commands and includes comprehensive error handling, responsive design, and modern development practices. The architecture supports easy scaling and feature additions while maintaining clean separation of concerns.