export interface Hackathon {
  id: string;
  name: string;
  description: string;
  domain: string;
  date: string;
  registrationUrl: string;
  imageUrl: string;
  createdAt: Date;
}

export interface ChatMessage {
  id: string;
  message: string;
  isUser: boolean;
  timestamp: Date;
}

export const DOMAIN_OPTIONS = [
  { value: "all", label: "All Domains" },
  { value: "web3", label: "Web3" },
  { value: "ai-ml", label: "AI/ML" },
  { value: "data-science", label: "Data Science" },
  { value: "cloud", label: "Cloud Computing" },
  { value: "web-dev", label: "Web Development" },
  { value: "healthcare", label: "Healthcare" },
  { value: "mobile", label: "Mobile Development" },
  { value: "cybersecurity", label: "Cybersecurity" },
];

export const DOMAIN_COLORS = {
  web3: "bg-purple-100 dark:bg-purple-900/30 text-purple-800 dark:text-purple-200",
  "ai-ml": "bg-green-100 dark:bg-green-900/30 text-green-800 dark:text-green-200",
  "data-science": "bg-blue-100 dark:bg-blue-900/30 text-blue-800 dark:text-blue-200",
  cloud: "bg-cyan-100 dark:bg-cyan-900/30 text-cyan-800 dark:text-cyan-200",
  "web-dev": "bg-orange-100 dark:bg-orange-900/30 text-orange-800 dark:text-orange-200",
  healthcare: "bg-red-100 dark:bg-red-900/30 text-red-800 dark:text-red-200",
  mobile: "bg-indigo-100 dark:bg-indigo-900/30 text-indigo-800 dark:text-indigo-200",
  cybersecurity: "bg-yellow-100 dark:bg-yellow-900/30 text-yellow-800 dark:text-yellow-200",
};

export const DOMAIN_ICONS = {
  web3: "fa-cube",
  "ai-ml": "fa-brain",
  "data-science": "fa-chart-line",
  cloud: "fa-cloud",
  "web-dev": "fa-code",
  healthcare: "fa-heartbeat",
  mobile: "fa-mobile-alt",
  cybersecurity: "fa-shield-alt",
};
