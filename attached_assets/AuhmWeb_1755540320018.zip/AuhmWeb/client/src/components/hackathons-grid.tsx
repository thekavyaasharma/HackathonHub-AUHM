import { useQuery } from "@tanstack/react-query";
import { HackathonCard } from "./hackathon-card";
import { Hackathon } from "@/types/hackathon";
import { Skeleton } from "@/components/ui/skeleton";

interface HackathonsGridProps {
  searchQuery: string;
  selectedDomain: string;
}

export function HackathonsGrid({ searchQuery, selectedDomain }: HackathonsGridProps) {
  const { data: hackathons, isLoading, error } = useQuery<Hackathon[]>({
    queryKey: ["/api/hackathons", { search: searchQuery, domain: selectedDomain }],
    queryFn: async () => {
      const params = new URLSearchParams();
      if (searchQuery) params.append("search", searchQuery);
      if (selectedDomain && selectedDomain !== "all") params.append("domain", selectedDomain);
      
      const response = await fetch(`/api/hackathons?${params}`);
      if (!response.ok) {
        throw new Error("Failed to fetch hackathons");
      }
      return response.json();
    },
  });

  if (error) {
    return (
      <div className="text-center py-12">
        <p className="text-red-600 dark:text-red-400">
          Failed to load hackathons. Please try again later.
        </p>
      </div>
    );
  }

  if (isLoading) {
    return (
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
        {Array.from({ length: 6 }).map((_, index) => (
          <div key={index} className="space-y-3">
            <Skeleton className="h-48 w-full rounded-xl" />
            <div className="p-6 space-y-3">
              <div className="flex justify-between items-center">
                <Skeleton className="h-6 w-20" />
                <Skeleton className="h-4 w-24" />
              </div>
              <Skeleton className="h-6 w-3/4" />
              <Skeleton className="h-16 w-full" />
              <Skeleton className="h-4 w-24" />
            </div>
          </div>
        ))}
      </div>
    );
  }

  if (!hackathons || hackathons.length === 0) {
    return (
      <div className="text-center py-12" data-testid="empty-state">
        <p className="text-gray-600 dark:text-gray-400 text-lg">
          {searchQuery || (selectedDomain && selectedDomain !== "all") 
            ? "No hackathons found matching your criteria."
            : "No hackathons available at the moment."
          }
        </p>
      </div>
    );
  }

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8" data-testid="hackathons-grid">
      {hackathons.map((hackathon) => (
        <HackathonCard key={hackathon.id} hackathon={hackathon} />
      ))}
    </div>
  );
}
