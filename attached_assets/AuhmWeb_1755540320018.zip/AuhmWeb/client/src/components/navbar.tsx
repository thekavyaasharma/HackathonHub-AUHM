import { useState } from "react";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Button } from "@/components/ui/button";
import { Search, Sun, Moon } from "lucide-react";
import { useTheme } from "@/hooks/use-theme";
import { DOMAIN_OPTIONS } from "@/types/hackathon";

interface NavbarProps {
  onSearch: (query: string) => void;
  onDomainFilter: (domain: string) => void;
  searchQuery: string;
  selectedDomain: string;
}

export function Navbar({ onSearch, onDomainFilter, searchQuery, selectedDomain }: NavbarProps) {
  const { theme, toggleTheme } = useTheme();

  return (
    <nav className="sticky top-0 z-40 bg-white/80 dark:bg-gray-900/80 backdrop-blur-md border-b border-gray-200 dark:border-gray-700">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center h-16">
          {/* Logo */}
          <div className="flex-shrink-0">
            <h1 className="text-2xl font-bold bg-gradient-to-r from-blue-600 to-violet-600 bg-clip-text text-transparent">
              AUHM
            </h1>
          </div>

          {/* Search and Filters */}
          <div className="flex-1 max-w-lg mx-8">
            <div className="relative">
              <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                <Search className="h-4 w-4 text-gray-400" />
              </div>
              <Input
                type="text"
                placeholder="Search hackathons..."
                value={searchQuery}
                onChange={(e) => onSearch(e.target.value)}
                className="pl-10"
                data-testid="input-search"
              />
            </div>
          </div>

          {/* Domain Filter and Theme Toggle */}
          <div className="flex items-center space-x-4">
            {/* Domain Filter */}
            <Select value={selectedDomain} onValueChange={onDomainFilter}>
              <SelectTrigger className="w-48" data-testid="select-domain">
                <SelectValue placeholder="All Domains" />
              </SelectTrigger>
              <SelectContent>
                {DOMAIN_OPTIONS.map((option) => (
                  <SelectItem key={option.value} value={option.value}>
                    {option.label}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>

            {/* Theme Toggle */}
            <Button
              variant="outline"
              size="icon"
              onClick={toggleTheme}
              className="bg-gray-100 dark:bg-gray-800 hover:bg-gray-200 dark:hover:bg-gray-700"
              data-testid="button-theme-toggle"
            >
              {theme === "light" ? (
                <Sun className="h-4 w-4 text-yellow-500" />
              ) : (
                <Moon className="h-4 w-4 text-blue-400" />
              )}
            </Button>
          </div>
        </div>
      </div>
    </nav>
  );
}
