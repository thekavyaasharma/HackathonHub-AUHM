import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { ExternalLink } from "lucide-react";
import { Hackathon, DOMAIN_COLORS, DOMAIN_ICONS } from "@/types/hackathon";

interface HackathonCardProps {
  hackathon: Hackathon;
}

export function HackathonCard({ hackathon }: HackathonCardProps) {
  const domainColor = DOMAIN_COLORS[hackathon.domain as keyof typeof DOMAIN_COLORS] || "bg-gray-100 dark:bg-gray-800 text-gray-800 dark:text-gray-200";
  const domainIcon = DOMAIN_ICONS[hackathon.domain as keyof typeof DOMAIN_ICONS] || "fa-calendar";

  return (
    <Card className="bg-white dark:bg-gray-800 rounded-xl shadow-lg overflow-hidden border border-gray-200 dark:border-gray-700 hover:shadow-2xl transition-all duration-300 transform hover:-translate-y-2 group">
      <div className="relative overflow-hidden">
        <img 
          src={hackathon.imageUrl} 
          alt={`${hackathon.name} banner`}
          className="w-full h-48 object-cover transition-transform duration-500 group-hover:scale-110"
          loading="lazy"
          data-testid={`img-hackathon-${hackathon.id}`}
        />
        <div className="absolute inset-0 bg-gradient-to-t from-black/20 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300"></div>
      </div>
      <CardContent className="p-6">
        <div className="flex items-center justify-between mb-3">
          <Badge className={`inline-flex items-center px-3 py-1 rounded-full text-xs font-medium ${domainColor}`}>
            <i className={`fas ${domainIcon} mr-1`}></i> 
            {hackathon.domain.charAt(0).toUpperCase() + hackathon.domain.slice(1).replace('-', '/')}
          </Badge>
          <span className="text-sm text-gray-500 dark:text-gray-400" data-testid={`text-date-${hackathon.id}`}>
            {hackathon.date}
          </span>
        </div>
        <h3 className="text-xl font-semibold text-gray-900 dark:text-gray-100 mb-2" data-testid={`text-name-${hackathon.id}`}>
          {hackathon.name}
        </h3>
        <p className="text-gray-600 dark:text-gray-400 text-sm mb-4" data-testid={`text-description-${hackathon.id}`}>
          {hackathon.description}
        </p>
        <a 
          href={hackathon.registrationUrl}
          target="_blank"
          rel="noopener noreferrer"
          className="inline-flex items-center text-blue-600 dark:text-blue-400 font-medium hover:text-blue-700 dark:hover:text-blue-300 transition-colors duration-200"
          data-testid={`link-register-${hackathon.id}`}
        >
          Register Now <ExternalLink className="ml-1 h-3 w-3" />
        </a>
      </CardContent>
    </Card>
  );
}
