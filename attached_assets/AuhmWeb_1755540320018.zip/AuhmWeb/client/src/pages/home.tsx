import { useState, useRef } from "react";
import { Navbar } from "@/components/navbar";
import { HeroSection } from "@/components/hero-section";
import { HackathonsGrid } from "@/components/hackathons-grid";
import { Chatbot } from "@/components/chatbot";
import { Footer } from "@/components/footer";

export default function Home() {
  const [searchQuery, setSearchQuery] = useState("");
  const [selectedDomain, setSelectedDomain] = useState("all");
  const [isChatbotOpen, setIsChatbotOpen] = useState(false);
  const hackathonsRef = useRef<HTMLElement>(null);

  const scrollToHackathons = () => {
    hackathonsRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  const openAIAssistant = () => {
    setIsChatbotOpen(true);
  };

  return (
    <div className="min-h-screen bg-white dark:bg-gray-900 transition-colors duration-300">
      <Navbar
        onSearch={setSearchQuery}
        onDomainFilter={setSelectedDomain}
        searchQuery={searchQuery}
        selectedDomain={selectedDomain}
      />
      
      <HeroSection onExploreClick={scrollToHackathons} onAIAssistantClick={openAIAssistant} />
      
      <section ref={hackathonsRef} className="py-16 lg:py-24 bg-white dark:bg-gray-900">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-3xl lg:text-4xl font-bold text-gray-900 dark:text-gray-100 mb-4">
              Upcoming Hackathons 2025
            </h2>
            <p className="text-lg text-gray-600 dark:text-gray-400 max-w-2xl mx-auto">
              Discover amazing hackathons across different domains. Register now and start building your future.
            </p>
          </div>
          
          <HackathonsGrid searchQuery={searchQuery} selectedDomain={selectedDomain} />
        </div>
      </section>
      
      <Footer />
      {isChatbotOpen && <Chatbot initialOpen={true} />}
    </div>
  );
}
